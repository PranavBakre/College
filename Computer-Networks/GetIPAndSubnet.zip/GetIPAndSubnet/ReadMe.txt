Execution instructions:

Linux:
	dotnet run
	-	within the project(folder with .csproj file)
	Or
	If dotnet 2.2.7 present run
	./bin/Release/netcoreapp2.2/linux-x64/GetIPAndSubnet

Windows- Executable File in .\bin\Release\netcoreapp2.2\win-x64

** Execution requires dotnet core 2.2 present on the machine
